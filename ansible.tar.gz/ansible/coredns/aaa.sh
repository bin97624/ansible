cd /opt/nginx/conf/sites-enabled/
sed -i "s/gcoj764.com/aaa/g" /opt/nginx/conf/sites-enabled/lotto.conf
