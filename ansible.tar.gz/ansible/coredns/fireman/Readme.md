# fireman

[![Build Status](http://35.222.74.118/api/badges/ctsportsrd/fireman/status.svg)](http://35.222.74.118/ctsportsrd/fireman)

## Quick start
* ` ./account.json` 裡面放 GCP service account credential file

```
// build
sh build.sh

// run
./fireman

// browser
http://localhost:9091
```


## api doc

| Code  | Method |                 Path                 |                  Desc                  |
| :---: | :----: | :----------------------------------: | :------------------------------------: |
|   1   |  GET   |           `/api/firewalls`           |           get all firewalls            |
|   2   |  POST  | `/api/firewall/{fw-id}/sourceranges` | update `Source ranges` of a `firewall` |

### 1

- method: GET
- path: `/api/firewalls`
- response
  - body
    - type: `json`
    - struct: `https://cloud.google.com/compute/docs/reference/rest/v1/firewalls/list`

### 2

- method: POST
- path: `/api/firewall/{fw-id}/sourceranges`
- request
  - body
    - type: `json`
    - struct: `[]string`
      - example: `[ "0.0.0.0/0", "1.1.1.1/2" ]` (new, old)
- response
  - body
    - type: `json`
    - struct: `https://cloud.google.com/compute/docs/reference/rest/v1/firewalls`

```sh
curl --header "Content-Type: application/json" \
  -X POST \
  -d '[["18.139.168.38/32"], ["12.111.112.12/32"]]' \
  http://localhost:9091/api/firewall/test/sourceranges 
```

- warning
  - Can not update default firewall

