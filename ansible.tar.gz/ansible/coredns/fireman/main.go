package main

import (
	"bitbucket.org/ozt/fireman/cmd"
)

func main() {
	cmd.Run()
}
