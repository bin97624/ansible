<template>
  <v-app>
    <v-app-bar app>
      <v-toolbar-title class="headline text-uppercase">
        <span>Fireman</span>
      </v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn
        text
        href="https://github.com/vuetifyjs/vuetify/releases/latest"
        target="_blank"
      >
        <span class="mr-2">Latest Release</span>
      </v-btn>
    </v-app-bar>

    <v-content>
      <Firewalls :firewalls="firewalls" />
    </v-content>
  </v-app>
</template>

<script>
import Firewalls from './components/Firewalls';
import Axios from 'axios';

export default {
  name: 'App',
  components: {
    Firewalls,
  },
  data: () => ({
    //
    firewalls: {}
  }),
  created() {
    this.loadFirewalls()
  },
  methods: {
      loadFirewalls() {
        Axios
          .get('/api/firewalls')
          .then(
            response => {
              // eslint-disable-next-line
              console.log("response ok ",response.data)
              this.firewalls = response.data
            }
          )
          .catch(
            error => {
              // eslint-disable-next-line
              console.log("response false", error)
              this.snackbar = true
            }
          )
      },
  }
};
</script>
