<template>
  <v-layout justify-center align-center row fill-height >
    <v-card
      max-width="1200"
      min-width="800"
      tile
    >
    <v-snackbar
          v-model="snackbar"
          color="red"
      >
      Loading false
      <v-btn
        color="blue"
        text
        :timeout="3000"
        @click="snackbar = false"
      >
        Close
      </v-btn>
    </v-snackbar>
      <v-expansion-panels  inset>
        <v-expansion-panel
          v-for="(item) in firewalls.items"
          :key="item.id"
          :value="target"
        >
          <div v-if="!defFWName.includes(item.name)">
            <v-expansion-panel-header>{{ item.name }}</v-expansion-panel-header>
            <v-expansion-panel-content>
              <v-flex >
                <v-text-field
                  :value="tags2str(item.targetTags)"
                  label="Tags"
                  filled
                  disabled
                ></v-text-field>
              </v-flex>
              <SourceRanges :fwName=item.name :fwID=item.id :sourceRanges=item.sourceRanges :tags=item.targetTags />
            </v-expansion-panel-content>
          </div>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-card>
  </v-layout>
</template>

<script>
import SourceRanges from './SourceRanges';
  export default {
    name: 'Firewalls',
    props: {
      firewalls: Object
    },
    components: {
      SourceRanges,
    },
    // mounted(){
    //   // this.init()
    //   this.loadFirewalls()
    // },
    data: () => ({
      snackbar: false,
      defFWName: [
        "default-allow-icmp",
        "default-allow-internal",
        "default-allow-rdp",
        "default-allow-ssh",
        "default-allow-http",
        "default-allow-https",
      ],
      target: "",
      theip: "",
      rules: {
        required: value => !!value || 'Required.',
        ip: value => {
          const pattern = /([1-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])(\.(\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])){3}\/(3[0-2]|[1-2]\d|\d)$/
          return pattern.test(value) || 'Invalid address.'
        },
      }
    }),
    watch: {
      target: function (val) {
        // eslint-disable-next-line
        console.warn(val)
      },
    },
    methods: {
      tags2str(arr) {
        if (arr === undefined) {
          return ""
        } else {
          return arr.join()
        }
      },
      clearInput() {
        this.theip = ""
      },
      pushIP() {
        this.sourceRanges.push(this.theip)
      },
      addIP() {
        if (this.rules.ip(this.theip) === true) {
          this.pushIP()
          this.clearInput()
        }
      },

    }
  }
</script>
