<template>
  <v-card
      class="mx-auto"
      max-width="600"
      tile
    >

    <v-snackbar
          v-model="snackbar"
          color="blue"
      >
      {{ snackbarText }}
      <v-btn
        :color="snackbarColor"
        text
        :timeout="3000"
        @click="snackbar = false"
      >
        Close
      </v-btn>
    </v-snackbar>

    <v-list-item>
      <v-list-item-content>
        <v-list-item-title v-bind:key=item v-for="(item, srID) in sourceRanges">
          {{ item }}
          <v-btn
            color="blue"
            text
            :tile="ipExist(srID)"
            @click="delSR(srID)"
          >
            Delete
          </v-btn>
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>

    <v-container grid-list-xl>
      <v-layout wrap>

        <v-flex xs12>
          <v-text-field
            label="Source IP ranges"
            placeholder="0.0.0.0/32"
            v-model="theip"
            :append-icon="'mdi-send'"
            @click:append="addIP"
            v-on:keyup.enter="addIP"
            :rules="[rules.ip]"
            filled
          ></v-text-field>
          <v-layout
            justify-center
            wrap
          >
              <v-dialog
                v-model="udtSRDialog"
                width="500"
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    color="blue"
                    dark
                    v-on="on"
                  >
                    Update
                  </v-btn>
                </template>

                <v-card>
                  <v-card-title
                    class="headline grey lighten-2"
                    primary-title
                  >
                    Update
                  </v-card-title>

                  <v-card-text>
                    <v-container fluid>
                      <v-layout>
                        <v-flex xs4>
                          <v-subheader>Firewalls Name: </v-subheader>
                        </v-flex>
                        <v-flex xs8>
                          <v-text-field
                            :value="fwName"
                            disabled
                          ></v-text-field>
                        </v-flex>
                      </v-layout>

                      <v-layout>
                        <v-flex xs4>
                          <v-subheader>Tags: </v-subheader>
                        </v-flex>
                        <v-flex xs8>
                          <v-text-field
                            :value="tags.join()"
                            disabled
                          ></v-text-field>
                        </v-flex>
                      </v-layout>

                      <v-layout>
                        <v-flex xs4>
                          <v-subheader>Source Ranges</v-subheader>
                        </v-flex>
                        <v-flex xs8>
                          <v-list-item>
                            <v-list-item-content>
                              <v-list-item-title v-bind:key=item v-for="item in sourceRanges">
                                {{ item }}
                              </v-list-item-title>
                            </v-list-item-content>
                          </v-list-item>
                        </v-flex>
                      </v-layout>

                    </v-container>
                  </v-card-text>

                  <v-divider></v-divider>

                  <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                      color="primary"
                      text
                      @click="updateBTN"
                    >
                      I accept
                    </v-btn>
                  </v-card-actions>
                </v-card>
              </v-dialog>


          </v-layout>
        </v-flex>
      </v-layout>
    </v-container>
  </v-card>
</template>

<script>
import axios from 'axios';
  export default {
    name: 'SourceRanges',
    props: {
      fwID: String,
      fwName: String,
      sourceRanges: Array,
      tags: Array,
    },
    data: () => ({
      toDel: [],
      snackbar: false,
      snackbarColor: "blue",
      snackbarText: "init",
      udtSRDialog: false,
      theip: "",
      rules: {
        required: value => !!value || 'Required.',
        ip: value => {
          const pattern = /([1-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])(\.(\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])){3}\/(3[0-2]|[1-2]\d|\d)$/
          return (value === "") || pattern.test(value) || 'Invalid address.'
        },
      },
    }),
    mounted(){
      if (this.oldsr === undefined) {
        this.oldsr = JSON.parse(JSON.stringify(this.sourceRanges))
        // eslint-disable-next-line
        console.log("deep copy2")
      } else {
        // eslint-disable-next-line
        console.log("unkown mounted")
      }
    },
    methods: {
      clearInput() {
        this.theip = ""
      },
      pushIP() {
        console.log("pushing ip ", this.theip)
        this.sourceRanges.push(this.theip)
      },
      addIP() {
        console.log("adding ip ", this.theip)
        axios
          .post('/api/firewall/'+this.fwID+'/check',
            {theip: this.theip}
          )
          .then(
            response => {
              // eslint-disable-next-line
              console.log(response.data)
              this.snackbar = true
              this.snackbarColor = "blue"
              this.snackbarText = "Success"
              // this.info = response.data.bpi
              this.udtSRDialog = false
              if (this.rules.ip(this.theip) === true) {
                this.pushIP()
                this.clearInput()
              }
            }
          )
          .catch(
            error => {
              if (error.response.data === undefined) {
                this.snackbarText = error
              } else {
                this.snackbarText = error.response.data
              }
              this.snackbar = true
              this.snackbarColor = "red"
            }
          )


      },
      delSR(id) {
        // eslint-disable-next-line
        console.log("delSR ", id)
        delete this.sourceRanges[id]
        this.toDel.push(id)
      },
      ipExist(id) {
        if (this.toDel.includes(id)) {
          return true
        } else {
          return false
        }
      },
      updateBTN() {
        // eslint-disable-next-line
        console.log("click")
        // eslint-disable-next-line
        console.log(this.fwID)
        // eslint-disable-next-line
        console.log(this.sourceRanges)
        axios
          .post('/api/firewall/'+this.fwID+'/sourceranges',
            [this.sourceRanges.filter(String), this.oldsr]
          )
          .then(
            response => {
              // eslint-disable-next-line
              console.log(response.data)
              this.snackbar = true
              this.snackbarColor = "blue"
              this.snackbarText = "Success"
              // this.info = response.data.bpi
              this.udtSRDialog = false
            }
          )
          .catch(
            error => {
              if (error.response.data === undefined) {
                this.snackbarText = error
              } else {
                this.snackbarText = error.response.data
              }
              this.snackbar = true
              this.snackbarColor = "red"
            }
          )
      },

    }
  }
</script>
