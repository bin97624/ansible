module.exports = {
    devServer: {
      proxy: 'http://localhost:9091'
    }
  }