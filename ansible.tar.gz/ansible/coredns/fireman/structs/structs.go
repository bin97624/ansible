package structs

// SA to get projectid
type SA struct {
	ProjectID string `json:"project_id"`
	Data      []byte
}

// // FWList all firewalls
// type FWList struct {
// 	*compute.FirewallList
// }

// // FW a
// type FW struct {
// 	*compute.Firewall
// }

// // CopyWithoutDefault :
// func (l *FWList) CopyWithoutDefault() (fl *FWList) {
// 	if l == nil {
// 		return nil
// 	}
// 	if len(l.Items) == 0 {
// 		return nil
// 	}
// 	bareList := []FW{}
// 	for i, e := range l.Items {
// 		if !l.inDefNameList(e.Name) {
// 			bareList = append(bareList, FW(e))
// 		}
// 	}
// }

// var defNameList = []string{"default-allow-icmp", "default-allow-internal", "default-allow-rdp", "default-allow-ssh"}

// func (l FWList) inDefNameList(n string) bool {
// 	for _, e := range defNameList {
// 		if e == n {
// 			return true
// 		}
// 	}
// 	return false
// }
