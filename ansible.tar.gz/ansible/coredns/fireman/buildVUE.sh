set -eux
cd ui
npm install
npm run build
