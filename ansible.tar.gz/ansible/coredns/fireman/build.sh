set -eux

sh buildVue.sh
sh buildGO.sh