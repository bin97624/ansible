package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"os"

	"bitbucket.org/ozt/fireman/structs"
	"google.golang.org/api/compute/v1"
	"google.golang.org/api/option"
)

var fwSRC *compute.FirewallsService
var projectID string

func getfwSRC() *compute.FirewallsService {
	if fwSRC == nil {
		return loadSAFile(getSAFilePath())
	}
	return fwSRC
}
func getProjectID() (string, error) {
	if projectID != "" {
		return projectID, nil
	}
	loadSAFile(getSAFilePath())
	if projectID == "" {
		return "", fmt.Errorf("Can not load `project_id`. Please check account.json")
	}
	return projectID, nil
}

func getSAFilePath() (saFilePath string) {
	args := os.Args
	switch len(args) {
	case 2:
		saFilePath = args[1]
	case 1:
		saFilePath = "./account.json"
	default:
		log.Fatal("Usage: fireman ./account.json")
	}
	return
}

func loadSAFile(saFilePath string) *compute.FirewallsService {
	jsonFile, err := os.Open(saFilePath)
	// if we os.Open returns an error then handle it
	if err != nil {
		checkOpenFileError(err)
		log.Fatal(err)
	}
	log.Println("Successfully Opened ServiceAccount file")
	// defer the closing of our jsonFile so that we can parse it later on
	defer jsonFile.Close()
	byteValue, _ := ioutil.ReadAll(jsonFile)

	var sa structs.SA
	if err := json.Unmarshal(byteValue, &sa); err != nil {
		log.Fatal(fmt.Errorf("json.Unmarshal sa file error: %v", err))
	}
	sa.Data = byteValue
	projectID = sa.ProjectID

	ctx := context.Background()

	cs, err := compute.NewService(ctx, option.WithCredentialsJSON(sa.Data))
	if err != nil {
		log.Fatal(err)
	}
	return cs.Firewalls
}

func checkOpenFileError(err error) {
	if err.Error() == "open ./account.json: no such file or directory" {
		f, err := os.Create("./account.json")
		if err != nil {
			fmt.Println(err)
			return
		}
		l, err := f.WriteString(safiletmp)
		if err != nil {
			fmt.Println(err)
			f.Close()
			return
		}
		fmt.Println(l, "bytes written successfully")
		err = f.Close()
		if err != nil {
			fmt.Println(err)
			return
		}
	}
}

var safiletmp = `
{
	"type": "service_account",
	"project_id": "testgcloud-247609",
	"private_key_id": "*****",
	"private_key": "*****",
	"client_email": "*****",
	"client_id": "*****",
	"auth_uri": "https://accounts.google.com/o/oauth2/auth",
	"token_uri": "https://oauth2.googleapis.com/token",
	"auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
	"client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/********"
}
`
