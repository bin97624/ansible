package cmd

import (
	"fmt"
	"log"
	"strings"

	"google.golang.org/api/compute/v1"
)

func getAllFirewalls() (*compute.FirewallList, error) {
	pi, err := getProjectID()
	if err != nil {
		return nil, err
	}
	return fwSRC.List(pi).Do()
}

func getFirewall(fwID string) (*compute.Firewall, error) {
	pi, err := getProjectID()
	if err != nil {
		return nil, err
	}
	return fwSRC.Get(pi, fwID).Do()
}

func updateFirewallSourceRanges(fwID string, sr []string, oldsr []string) (*compute.Firewall, error) {
	fw, err := getFirewall(fwID)
	if err != nil {
		return nil, err
	}
	if inDefaultList(fw.Name) {
		return nil, fmt.Errorf("Can not update `default` firewall: %v", fw.Name)
	}
	log.Println(fw.SourceRanges)
	if strings.Join(fw.SourceRanges, "") == strings.Join(oldsr, "") {
		fw.SourceRanges = sr
	} else {
		return nil, fmt.Errorf("Can not update, someone change it after you get the latest.%v", "")
	}
	pjID, err := getProjectID()
	if err != nil {
		return nil, err
	}
	_, err = fwSRC.Update(pjID, fwID, fw).Do()
	if err != nil {
		return nil, err
	}
	return fw, nil
}

func inDefaultList(n string) bool {
	dfList := []string{
		"default-allow-internal",
		"default-allow-icmp",
		"default-allow-rdp",
		"default-allow-ssh",
	}
	for _, dn := range dfList {
		if dn == n {
			return true
		}
	}
	return false
}
