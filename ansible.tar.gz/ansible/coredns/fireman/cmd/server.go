package cmd

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"strings"

	"bitbucket.org/ozt/fireman/aws/iprange"
	"github.com/emicklei/go-restful"
	"github.com/gobuffalo/packr"
	"google.golang.org/api/compute/v1"
)

// RunServer :
func RunServer() {
	wsContainer := restful.NewContainer()

	box := packr.NewBox("../ui/dist")
	wsContainer.Handle("/", http.FileServer(box))

	ws := new(restful.WebService)

	ws.
		Path("/api").
		Consumes(restful.MIME_XML, restful.MIME_JSON).
		Produces(restful.MIME_JSON, restful.MIME_XML)

	ws.Route(ws.GET("/firewalls").To(listFirewalls).
		Doc("get firewalls").
		Writes(compute.FirewallList{}))

	ws.Route(ws.POST("/firewall/{fw-id}/sourceranges").To(postSRs)).
		Doc("post sourceRanges to a firewall")

	ws.Route(ws.POST("/firewall/{fw-id}/check").To(postCheck)).
		Doc("check ip range")

	wsContainer.Add(ws)

	log.Println("run on :9091")
	log.Fatal(http.ListenAndServe(":9091", wsContainer))
}

func listFirewalls(request *restful.Request, response *restful.Response) {

	l, err := getAllFirewalls()
	if err != nil {
		response.WriteError(http.StatusBadGateway, err)
		return
	}
	response.WriteAsJson(l)
}

func postSRs(request *restful.Request, response *restful.Response) {

	fwID := request.PathParameter("fw-id")
	srs := [][]string{}
	err := request.ReadEntity(&srs)

	if err != nil {
		response.WriteError(http.StatusBadRequest, err)
		return
	}

	// is new Ip range belong to AWS ?
	if err := awsIprangeMiddleware(srs[0]); err != nil {
		response.WriteError(http.StatusForbidden, err)
		return
	}

	fw, err := updateFirewallSourceRanges(fwID, srs[0], srs[1])
	if err != nil {
		response.WriteError(http.StatusBadGateway, err)
		return
	}
	response.WriteAsJson(fw)
}

func postCheck(request *restful.Request, response *restful.Response) {

	srs := &struct {
		Theip string `json:"theip"`
	}{}

	err := request.ReadEntity(srs)
	if err != nil {
		log.Println("ReadEntity error ", err.Error(), srs)
		response.WriteError(http.StatusBadRequest, err)
		return
	}
	ip := srs.Theip
	// for _, ip := range srs[1] {
	log.Println(ip)
	ip = strings.Split(ip, "/")[0]
	trial := net.ParseIP(ip)
	if trial.To4() == nil {
		e := fmt.Errorf("%v is not an IPv4 address\n", trial)
		response.WriteError(http.StatusForbidden, e)
		return
	}
	// }

	// is new Ip range belong to AWS ?
	if err := awsIprangeMiddleware([]string{ip}); err != nil {
		response.WriteError(http.StatusForbidden, err)
		return
	}

	response.WriteAsJson("done")
}

func awsIprangeMiddleware(newRanges []string) error {

	for _, ipRange := range newRanges {

		// range into ip
		ip := strings.Split(ipRange, "/")[0]

		awsIps, err := iprange.ListIps()
		if err != nil {
			return fmt.Errorf("Load aws ip range fail")
		}

		isAllow, e := iprange.Match(strings.Trim(ip, " "), awsIps)
		if e != nil {
			return e
		}
		if !isAllow {
			return fmt.Errorf("IP : %s is invalid, Only allow AWS IP", ip)
		}
	}

	return nil
}
