package cmd

func init() {
	fwSRC = getfwSRC()
}

// Run command
func Run() {
	RunServer()

}
