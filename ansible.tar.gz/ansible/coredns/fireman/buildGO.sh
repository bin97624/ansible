set -eux
go get -u github.com/gobuffalo/packr/packr
go get -u github.com/gobuffalo/packr
$GOPATH/bin/packr
go build
