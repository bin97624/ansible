package iprange

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestIPRange(t *testing.T) {
	ips, err := ListIps()
	if len(ips) == 0 || err != nil {
		t.Fail()
	}
}

func TestMatch(t *testing.T) {
	// https://ip-ranges.amazonaws.com/ip-ranges.json
	awsIps := []string{"15.230.56.104/31", "35.180.0.0/16"}
	isMatch, err := Match("35.180.20.0", awsIps)

	if err != nil || !isMatch {
		t.Fail()
	}
}

func TestInRange(t *testing.T) {
	from := "18.138.0.0"
	to := getRangeTo(from, 15)
	assert.Equal(t, "18.139.255.255", to)

	// test 32 mask
	from = "52.93.240.164"
	to = getRangeTo(from, 32)
	assert.Equal(t, from, to)
}

func TestIsInRange(t *testing.T) {
	iir := isInRange("18.139.168.38", "18.138.0.0", "18.139.255.255")
	assert.True(t, iir)

	// test 32 mask
	iir = isInRange("18.139.168.38", "18.139.168.38", "18.139.168.38")
	assert.True(t, iir)

	iir = isInRange("18.140.168.38", "18.138.0.0", "18.139.168.38")
	assert.False(t, iir)
}
