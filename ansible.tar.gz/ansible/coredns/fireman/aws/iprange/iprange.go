package iprange

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"strconv"
	"strings"

	"github.com/brotherpowers/ipsubnet"
	"github.com/sirupsen/logrus"
)

const ipRangeURL = "https://ip-ranges.amazonaws.com/ip-ranges.json"

func ListIps() (ips []string, err error) {
	client := &http.Client{}
	req, err := http.NewRequest("GET", ipRangeURL, nil)
	var jsonResp []byte

	if err != nil {
		return nil, err
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()
	if body, err := ioutil.ReadAll(resp.Body); err != nil {
		logrus.Panic("read fail : ", err.Error())
	} else {
		jsonResp = body
	}
	iprange := &ipRanges{}
	if err := json.Unmarshal(jsonResp, iprange); err != nil {
		log.Println(err.Error())
		return nil, err
	}
	for _, v := range iprange.Prefixes {
		ips = append(ips, v.IpPrefix)
	}
	return ips, nil
}

// input
// 	ip: e.g. 123.123.123.123
// 	awsIps : aws ip range
func Match(ip string, awsIps []string) (bool, error) {

	for _, aIp := range awsIps {
		aIpPair := strings.Split(aIp, "/")
		from := aIpPair[0]
		size, _ := strconv.Atoi(aIpPair[1])
		to := getRangeTo(from, size)
		if isInRange(ip, from, to) {
			return true, nil
		}
	}
	return false, nil
}

type ipRanges struct {
	Prefixes []*prefixes `json:"prefixes"`
}

type prefixes struct {
	IpPrefix string `json:"ip_prefix"`
}

func getRangeTo(from string, size int) (to string) {
	if size >= 32 {
		to = from
		return
	}
	sub := ipsubnet.SubnetCalculator(from, size)
	r := sub.GetIPAddressRange()
	to = r[1]
	return
}

func isInRange(ip string, from string, to string) bool {
	ip1, ip2 := net.ParseIP(from), net.ParseIP(to)
	trial := net.ParseIP(ip)
	if trial.To4() == nil {
		fmt.Printf("%v is not an IPv4 address\n", trial)
		return false
	}
	if bytes.Compare(trial, ip1) >= 0 && bytes.Compare(trial, ip2) <= 0 {
		fmt.Printf("%v is between %v and %v\n", trial, ip1, ip2)
		return true
	}
	// fmt.Printf("%v is NOT between %v and %v\n", trial, ip1, ip2)
	return false
}
