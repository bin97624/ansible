cd ~/
ssh-keygen -t rsa -N '' -f id_rsa -q
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
ssh -D 0.0.0.0:10892 -q -C -N -f 127.0.0.1
